#include "solution.h"
#include <iostream>
using namespace std;

int main() {
    Solution s;
    cout << "Result: " << s.add(1, 5) << endl;
    return 0;
}
