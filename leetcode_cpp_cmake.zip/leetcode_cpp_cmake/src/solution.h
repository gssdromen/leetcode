#pragma once
#include <iostream>
using namespace std;

class Solution {
public:
    int add(int a, int b);
};
