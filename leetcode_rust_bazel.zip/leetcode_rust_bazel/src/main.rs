mod solution;

fn main() {
    let result = solution::add(3, 4);
    println!("Result: {}", result);
}
